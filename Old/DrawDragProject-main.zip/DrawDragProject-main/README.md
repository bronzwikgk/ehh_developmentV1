# DrawDragProject
withgout using canvas we draw a different divs

Testing page
https://shital1995dev.github.io/
