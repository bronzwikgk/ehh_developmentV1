<a target="_blank" href="https://chrome.google.com/webstore/detail/lhfiglpmnendbchimlikaeachppfonmm">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-app-samples/master/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


# Clock

A widget-like application that provides a world clock, an alarm, a timer and a stopwatch. 

## APIs

* [Sync Storage API](http://developer.chrome.com/apps/storage.html)
* [Runtime](http://developer.chrome.com/apps/app.runtime.html)
* [Window](http://developer.chrome.com/apps/app.window.html)

     
## Screenshot
![screenshot](/samples/clock/assets/screenshot_1280_800.png)

