Dojo
====
This directory contains a script (build.sh) to generate an "one-app-to-rule-them-all": an app that executes all the other apps in the repository.

To create the app, run `build.sh` on your Mac or Linux. It is necessary to have Perl installed (MacOsX and Linux both have by default). The generated kitchen-sink app will be in `dojo.crx`.

Special thanks to @tomtasche for the idea and for the non-automatic implementation, which ultimately resulted in this script.

Please join the [Chromium Apps](https://groups.google.com/a/chromium.org/forum/?fromgroups#!forum/chromium-apps) group for general discussion. We're also available on IRC at #chromium-apps ([Freenode](http://freenode.net/)).
