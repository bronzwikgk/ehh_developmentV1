<a target="_blank" href="https://chrome.google.com/webstore/detail/jpabeekbjicamajjcfejnochhmlbpgjh">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-app-samples/master/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


# Google Drive Uploader

Uses the `chrome.identity.getAuthToken()` API to perform OAuth2 and
access the Google Drive API.

To upload files: drag in files from the desktop onto the app.

## APIs

* [Identity](http://developer.chrome.com/apps/identity.html)


## Screenshot
![screenshot](/samples/gdrive/assets/screenshot_1280_800.png)
