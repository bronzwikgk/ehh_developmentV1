<a target="_blank" href="https://chrome.google.com/webstore/detail/ohndmecdhlgohpibepbboddcoecomnpc">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-app-samples/master/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


chrome.hid API Sample
=====================

This sample demonstrates usage of the `chrome.hid` API.

## APIs

* [HID](https://developer.chrome.com/apps/hid)
* [Runtime](https://developer.chrome.com/apps/runtime)
* [Window](https://developer.chrome.com/apps/app_window)

## Screenshot
![screenshot](/samples/hid/assets/screenshot_1280_800.png)
