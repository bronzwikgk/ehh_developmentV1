ATTENTION contributors: this directory (sample_support) should not be changed.
It is automatically updated and should not contain anything that is specific
to this sample.